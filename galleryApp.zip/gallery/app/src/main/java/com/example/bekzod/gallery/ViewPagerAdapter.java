package com.example.bekzod.gallery;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

/**
 * Created by Bekzod on 3/11/2018.
 */

public class ViewPagerAdapter extends FragmentPagerAdapter {
    ArrayList<Fragment> fragments=new ArrayList<>();
    ArrayList<String> titles=new ArrayList<>();

    public void addPageAdapter(Fragment fragment, String title){
            this.fragments.add(fragment);
            this.titles.add(title);
    }
    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        if(fragments.get(position)!=null)
        return fragments.get(position);
        else return null;
    }

    @Override
    public int getCount() {
        return fragments.size();
    }
}
