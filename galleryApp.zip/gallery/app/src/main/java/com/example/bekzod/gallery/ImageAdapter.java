package com.example.bekzod.gallery;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

/**
 * Created by Bekzod on 4/17/2018.
 */

public class ImageAdapter extends BaseAdapter {

    Context myContext;
    public int[] image={R.drawable._1, R.drawable._2,R.drawable._3,R.drawable._4,R.drawable._5,R.drawable._6,R.drawable._7,R.drawable._8,R.drawable._9,R.drawable._10,R.drawable._11,R.drawable._12,R.drawable._13,};

    public ImageAdapter(Context myContext) {
        this.myContext = myContext;
    }

    @Override
    public int getCount() {
        return image.length;
    }

    @Override
    public Object getItem(int i) {
        return image[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }
    @NonNull
    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        ImageView myImage;
        if (view == null) {
            myImage = new ImageView(myContext);
            myImage.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            myImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
            myImage.setPadding(0, 0, 0, 0);
        } else {
            myImage = (ImageView) view;
        }
        myImage.setImageResource(image[i]);
        return myImage;
    }
}