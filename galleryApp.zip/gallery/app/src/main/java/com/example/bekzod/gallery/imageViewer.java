package com.example.bekzod.gallery;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class imageViewer extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_viewer);

        Intent i = getIntent();
        //https://disk.yandex.ru/client/disk/myImages
        // Selected image id
        int position = i.getExtras().getInt("id");
        ImageAdapter adapter=new ImageAdapter(this);
        ImageView imageView = (ImageView) findViewById(R.id.myFullScreenImage);
        imageView.setImageResource(adapter.image[position]);
    }
}
