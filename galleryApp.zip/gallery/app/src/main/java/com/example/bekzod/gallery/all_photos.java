package com.example.bekzod.gallery;


import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class all_photos extends Fragment {


    public all_photos() {
        // Required empty public constructor
    }

    GridView gridView;
    ArrayList<String>name_list;
    ArrayList<String>name_path_list;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View myView=inflater.inflate(R.layout.fragment_all_photos, container, false);
        /*File myFile=new File("sdcard/photos/");
        if(!myFile.exists()){
            myFile.mkdir();
        }
        load_image_files(myFile);
        gridView=(GridView) myView.findViewById(R.id.all_files_gridView);
        gridView.setNumColumns(2);
        allPicturesAdapter adapter=new allPicturesAdapter(myView.getContext(),name_path_list);
        gridView.setAdapter(adapter);*/
        return myView;
    }
    public void load_image_files(File dir) {
        String extention = ".jpg";
        File[] listFile = dir.listFiles();
        if (listFile != null) {
            for (int i = 0; i < listFile.length; i++) {

                if (listFile[i].isDirectory()) {
                    load_image_files(listFile[i]);
                } else {
                    if (listFile[i].getName().endsWith(extention)) {
                        name_list.add(listFile[i].getName());
                        name_path_list.add(listFile[i].getAbsolutePath());

                    }
                }
            }
        }
    }

    public class allPicturesAdapter extends BaseAdapter {

        Context myContext;
        ArrayList<String> image_paths;

        public allPicturesAdapter(Context myContext,ArrayList<String> image_paths) {
            this.myContext = myContext;
            this.image_paths=image_paths;
        }

        @Override
        public int getCount() {
            return image_paths.size();
        }

        @Override
        public Object getItem(int i) {
            return image_paths.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }
        @NonNull
        @Override
        public View getView(final int i, View view, ViewGroup viewGroup) {
            ImageView myImage;
            if (view == null) {
                myImage = new ImageView(myContext);
                myImage.setLayoutParams(new GridView.LayoutParams(300,300));
                myImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
                myImage.setPadding(0, 0, 0, 0);
            } else {
                myImage = (ImageView) view;
            }
            Picasso.with(myContext)
                    .load(image_paths.get(i))
                    .into(myImage);
            return myImage;
        }
    }

}
