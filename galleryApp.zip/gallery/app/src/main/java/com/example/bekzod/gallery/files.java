package com.example.bekzod.gallery;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import org.json.JSONTokener;


/**
 * A simple {@link Fragment} subclass.
 */
public class files extends Fragment {


    public files() {
        // Required empty public constructor
    }
ImageView myImageView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View myView=inflater.inflate(R.layout.fragment_files, container, false);
        myImageView=(ImageView)myView.findViewById(R.id.imageView);
       // Picasso.get().load("http://i.imgur.com/DvpvklR.png").into(imageView);
        // Inflate the layout for this fragment
        String url="https://downloader.disk.yandex.ru/disk/a00dff4164f83a49d523367d85d2847883f85801a71896dcce91ca21ccb3c191/5ad70d2f/alUxljVy2jYXvIp4MtEvzzL_yem9pThhjwd5xl6cPoU5v9aAtxYB-NyrAx5_e6iSm2kScnxWmS_aAD2LUUk6_g%3D%3D?uid=637733096&filename=_13.JPG&disposition=attachment&hash=&limit=0&content_type=image%2Fjpeg&fsize=89024&hid=51a2c5d7f05533ec6e92ffa4d7c0f2b9&media_type=image&tknv=v2&etag=58f1cece2ee77b8e32e255b910315cd3";
        Picasso.with(getContext()).load(url).into(myImageView);
        return myView;
    }

}
