package com.example.bekzod.gallery;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.PopupMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class lenta extends Fragment {
    ImageAdapter adapter;
    GridView gridView;
    public lenta() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View myView=inflater.inflate(R.layout.fragment_lenta, container, false);
        gridView=(GridView) myView.findViewById(R.id.myGridView);
        gridView.setNumColumns(2);

        adapter=new ImageAdapter(myView.getContext());
        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent myIntent=new Intent(getActivity(), imageViewer.class);
                myIntent.putExtra("id", i);
                startActivity(myIntent);
            }
        });
        return myView;
    }


}
